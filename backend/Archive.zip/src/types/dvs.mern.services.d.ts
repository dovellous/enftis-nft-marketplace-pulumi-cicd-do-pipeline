declare global {
    var country: string;
    function multiply(a: number, b: number): number;
}

export {};