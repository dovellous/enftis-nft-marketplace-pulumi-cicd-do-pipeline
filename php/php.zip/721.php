<?php

$str="getBaseURI|
getContractURI|
getTokenURI|tokenId
tokenURI|tokenId
getOwner|
getMarketplaceAddress|
getRoyaltyFraction|
getRoyaltyReceiver|
getTokenRoyaltyInfo|tokenId,tokenPrice
getRoyaltyFeeDenominator|
getTokenMaximumSupply|
totalSupply|
getTokenCurrentSupply|
getTokenCurrentId|
getTokenMintingFee|
getTokensMintedByMe|
getTokensMintedByAddress|account
getTokenMinter|tokenId
getTokenMintee|tokenId
getTokensCreatedByMe|
getTokensCreatedByAddress|account
getTokenCreator|tokenId
getTokensOwnedByMe|
getTokensOwnedByAddress|account
getTokenOwner|tokenId
getAccountTokenBalance|account
getNFTItem|tokenId
getNFTItems|
getTokenAuditTrail|tokenId
collectionName|
collectionSymbol|
collectionCategory|
collectionDescription|
collectionBannerMedia|
collectionDisplayPicture|
searchTokenId|
searchTokenURI|stringmemorystring
searchTimestamp|itemKey,
searchAddress|itemKey,address
supportsInterface|interfaceId
burnToken|tokenId
tokenURIExists|tokenURI
mintNewToken|to,tokenURI,royaltyFraction
setRoyalties|royaltyReceiver,royaltyFraction,tokenId
disableRoyaltiesUntil|timestamp
transferToken|to,tokenId,from
grantAdminRole|addressaccount
revokeAdminRole|addressaccount
renounceAdminRole|addressaccount
renounceContractOwnership|
grantMinterRole|addressaccount
revokeMinterRole|addressaccount
renounceMinterRole|addressaccount
approveAddressForToken|account,tokenId
setBaseURI|stringcalldatanewBaseURI
setContractURI|newContractURI
setCollectionDescription|stringcalldatadescription
setCollectionBannerMedia|stringcalldatabannerURL
setCollectionDisplayPicture|stringcalldataphotoURL
setMarketplaceAddress|newMarketplaceAddress
setMintingFee|newMintingFee
setLoggerAddress|logger
setNewOwner|newOwner
togglePause|";

$lines = explode("\n", $str);

foreach($lines as $line){
    
    $fa = explode("|", $line);
    
    $func = $fa[0];
    
    $params = [];
    
    if(strlen($fa[1])>1){
        
        $params = explode(",", $fa[1]);
        
    }
    
    $fx = "
    
    /// $func
    
    const { erc721_{$func}_config } = usePrepareContractWrite({
        address: ERC721Address,
        abi: ERC721ABI,
        functionName: '$func',
        args: [".implode(",",$params)."],
    });
      
    const { 
        data: erc721_{$func}_data , 
        write: erc721_{$func}_write 
    } = useContractWrite(
        erc721_{$func}_config
    );
 
    const { 
        isLoading: erc721_{$func}_is_loading, 
        isSuccess: erc721_{$func}_is_success, 
        isError: erc721_{$func}_is_error 
    } = useWaitForTransaction({
        hash: erc721_{$func}_data?.hash,
     });
    
    /// end $func
    
    ";
    
    echo $fx."\n";
    
}



