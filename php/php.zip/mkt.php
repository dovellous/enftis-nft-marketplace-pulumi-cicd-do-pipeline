<?php

$str="getContractURI|
getTokenListingFee|
getOwner|
getCurrentIndexedID|
getNFTMarketItemsListedByAddress|account
getNFTItemUserAddresses|marketItemId
getNFTItemsMintedByAddress|account
getNFTItemsCreatedByAddress|account
getNFTItemsOwnedByMe|
getNFTItemsOwnedByAddress|account
getNFTMarketItem|marketItemId
getNFTMarketItems|
getNFTItemAuditTrail|marketItemId
getTokenOwnermkt|account,tokenId
getNFTmktItems|account
getTokenOwner721|account,tokenId
getAuctionItem|tokenIndexedID
getAuctionItems|
getNFT721Items|account
searchTokenId|tokenId,extendedSearchAddress
searchTokenURI|uri,extendedSearchAddress
searchTimestamp|itemKey,timestamp,extendedSearchAddress
searchAddress|itemKey,address,extendedSearchAddress
supportsInterface|interfaceId
grantAdminRole|account
revokeAdminRole|account
renounceAdminRole|account
renounceContractOwnership|
setContractURI|newContractURI
setListingFee|newListingFee
setLoggerAddress|logger
setNewOwner|newOwner
createNFTMarketItem|tokenContractAddress,tokenInterfaceId,tokenId,price,auctionHours
changeTokenOwnership|tokenInterfaceId,tokenContractAddress,from,to,tokenId
listNFTMarketItem|tokenIndexedID,newPrice
delistNFTMarketItem|tokenIndexedID,removeFromMarketplace
createMarketSale|tokenIndexedID
executeMarketItemSale|marketplaceItem
bidNFTMarketAuctionItem|tokenIndexedID
sellNFTMarketAuctionItem|tokenIndexedID
fetchUserBids|";

$lines = explode("\n", $str);

foreach($lines as $line){
    
    $fa = explode("|", $line);
    
    $func = $fa[0];
    
    $params = [];
    
    if(strlen($fa[1])>1){
        
        $params = explode(",", $fa[1]);
        
    }
    
    $fx = "
    
    /// $func
    
    const { ercmktp_{$func}_config } = usePrepareContractWrite({
        address: ERCMKTPddress,
        abi: ERCMKTPABI,
        functionName: '$func',
        args: [".implode(",",$params)."],
    });
      
    const { 
        data: ercmktp_{$func}_data , 
        write: ercmktp_{$func}_write 
    } = useContractWrite(
        ercmktp_{$func}_config
    );
 
    const { 
        isLoading: ercmktp_{$func}_is_loading, 
        isSuccess: ercmktp_{$func}_is_success, 
        isError: ercmktp_{$func}_is_error 
    } = useWaitForTransaction({
        hash: ercmktp_{$func}_data?.hash,
     });
    
    /// end $func
    
    ";
    
    echo $fx."\n";
    
}



