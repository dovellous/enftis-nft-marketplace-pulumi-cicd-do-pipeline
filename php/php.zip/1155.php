<?php

$str="baseURI|
uri|tokenId
tokenURI|tokenId
tokenURIExists|uri
getTokenURI|
getMarketplaceAddress|
getTokenSupplies|tokenId
getTokenMaximumSupply|
getTokenCurrentSupply|
getTokenMintingFee|
getTokensMintedByMe|
getTokensMintedByAddress|address
getTokenMinter|tokenId
getTokenMintee|tokenId
getTokensCreatedByMe|
getTokensCreatedByAddress|account
getTokenCreator|tokenId
getTokensOwnedByMe|
getTokensOwnedByAddress|account
getTokenOwner|tokenId
getNFTItem|tokenId
getNFTItems|
getTokenAuditTrail|tokenId
searchTokenId|tokenId
searchTokenURI|query
searchTimestamp|key, value
searchAddress|key, value
supportsInterface|interfaceId
setDefaultRoyalty|receiver, feeNumerator
deleteDefaultRoyalty|
resetTokenRoyalty|tokenId
setTokenRoyalty|tokenId, receiver, feeNumerator
transferToken|from, to, tokenId, amount, data
setBaseURI|newURI 
grantAdminRole|address
revokeAdminRole|address
renounceAdminRole|address
renounceContractOwnership|
grantMinterRole|address
revokeMinterRole|address
renounceMinterRole|address
setTokenURI|tokenId, tokenURI
setMarketplaceAddress|address
setMintingFee|fee
setLoggerAddress|address
setNewOwner|address
burn|from, to, amount
burnBatch|address, ids, values 
mintSingle| to, tokenId, amount, maximumSupply, tokenURI, data 
mintBatch| to, tokenIds, amounts, maximumSupplies, tokenURIs, data 
pause|
unpause|";

$lines = explode("\n", $str);

foreach($lines as $line){
    
    $fa = explode("|", $line);
    
    $func = $fa[0];
    
    $params = [];
    
    if(strlen($fa[1])>1){
        
        $params = explode(",", $fa[1]);
        
    }
    
    $fx = "
    
    /// $func
    
    // instantiate empty variables for the method: $func
    const [erc1155_{$func}_args, set_erc1155_{$func}_args] = useState<Array<any> | undefined>(undefined);
    
    // Function to invoke when '$func' is successful.
    const [erc1155_{$func}_success_cb, set_erc1155_{$func}_success_cb] = useState<Function | any >(()=>{}));
    
    // Function to invoke when an error is thrown while attempting to execute '$func' .
    const [erc1155_{$func}_errors_cb, set_erc1155_{$func}_errors_cb] = useState<Function>(()=>{});
    
    // Function to invoke when '$func' is settled (either successfully sent, or an error has thrown).
    const [erc1155_{$func}_settled_cb, set_erc1155_{$func}_settled_cb] = useState<Function>(()=>{});
    
    // Prepare the write function for the '$func' method
    const { config: erc1155_{$func}_config } = usePrepareContractWrite({
        ...erc1155_config,
        functionName: '$func',
        args: erc1155_{$func}_args as Array<any> | undefined,
        chainId: currentChain.id,
        account: walletAddress,
        enabled: false,
        onSuccess(data:any) {
          typeof erc1155_{$func}_success_cb === 'function' && erc1155_{$func}_success_cb(data);
        },
        onError(error:any) {
          typeof erc1155_{$func}_errors_cb === 'function' && erc1155_{$func}_errors_cb(error);
        },
        onSettled(data:any, error:any) {
          typeof erc1155_{$func}_settled_cb === 'function' && erc1155_{$func}_settled_cb(data, error);
        },
        onMutate({ args, overrides }) {
          console.log('Mutate', { args, overrides }:any)
        },
    });
    
    // Override destructred vars
    const { 
        data: erc1155_{$func}_data , 
        write: erc1155_{$func}_write 
    } = useContractWrite(
        erc1155_{$func}_config
    );
 
    // Wait for '$func' to finish executing
    const { 
        isLoading: erc1155_{$func}_is_waiting, 
        isSuccess: erc1155_{$func}_is_success, 
        isError: erc1155_{$func}_is_error 
    } = useWaitForTransaction({
        hash: erc1155_{$func}_data?.hash,
     });
    
    
    // Set the variables for '$func' which are: [".implode(",", $params)."]
    // This will call the write function for '$func'
    const erc1155_{$func}_exe:any = (...args:any) => {
         
        set_erc1155_{$func}_args(args);
         
    }
    
    // Listen for argument changes then call the function
    useEffect(() => {
        
        erc1155_{$func}_write?.();
        
    }, [erc1155_{$func}_args]);
    
    /// end $func
    
    ";
    
    echo $fx."\n";
    
}



